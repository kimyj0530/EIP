function check(){
	if(frm.custno.value.length==0){
		alert("회원번호 X");
		frm.custno.focus();
		return false;
	} else if(frm.custname.value.length==0){
		alert("회원성명 X");
		frm.custname.focus();
		return false;
	} else if(frm.phone.value.length==0){
		alert("회원전화 X");
		frm.phone.focus();
		return false;
	} else if(frm.address.value.length==0){
		alert("회원주소 X");
		frm.address.focus();
		return false;
	} else if(frm.joindate.value.length==0){
		alert("가입일자 X");
		frm.joindate.focus();
		return false;
	} else if(frm.grade.value.length==0){
		alert("고객등급 X");
		frm.grade.focus();
		return false;
	} else if(frm.city.value.length==0){
		alert("도시코드 X");
		frm.city.focus();
		return false;
	} else{
		alert("성공");
		document.frm.submit();
	}
}
function res(){
	document.frm.reset()
}